import PyNomad

PyNomad.info()

PyNomad.help('BB_OUTPUT')
