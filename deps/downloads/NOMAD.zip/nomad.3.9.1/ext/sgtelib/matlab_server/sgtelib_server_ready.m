function ready = sgtelib_server_ready

ready = sgtelib_server_ping;
